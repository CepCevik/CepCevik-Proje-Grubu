import React from 'react';

const PostCard = ({ post, isClubOwner, onRefresh, onLike, onVote }) => {
    const config = {
        announcement: { color: '#3498db', icon: '📢', label: 'Duyuru' },
        event: { color: '#2ecc71', icon: '📅', label: 'Etkinlik' },
        giveaway: { color: '#e74c3c', icon: '🎁', label: 'Çekiliş' },
        poll: { color: '#9b59b6', icon: '📊', label: 'Anket' }
    }[post.post_type];

    return (
        <div className="post-card" style={{ borderLeft: `6px solid ${config.color}` }}>
            <div className="card-header">
                <span className="type-badge" style={{ backgroundColor: config.color }}>
                    {config.icon} {config.label}
                </span>
                <span className="post-date">{new Date(post.posted_date).toLocaleDateString()}</span>
            </div>
            
            <div className="card-body">
                <p className="post-text">{post.text}</p>
                
                {/* Etkinlik Detayı */}
                {post.post_type === 'event' && (
                    <div className="detail-row">📍 {post.details.location} | ⏰ {new Date(post.details.expire_date).toLocaleString()}</div>
                )}

                {/* Anket Şıkları */}
                {post.post_type === 'poll' && (
                    <div className="poll-options">
                        {post.details.options.split(',').map(opt => (
                            <button key={opt} onClick={() => onVote(post.id, opt)} className="poll-btn">{opt}</button>
                        ))}
                    </div>
                )}

                {/* Çekiliş Alanı */}
                {post.post_type === 'giveaway' && (
                    <div className="giveaway-area">
                        <span>👥 {post.details.participant_count} Katılımcı</span>
                        {post.details.is_finished ? (
                            <div className="winners">🏆 Kazananlar: {post.details.winners.join(', ')}</div>
                        ) : (
                            isClubOwner && <button onClick={() => onRefresh(post.id, 'finish')} className="btn-finish">Sonuçlandır</button>
                        )}
                    </div>
                )}
            </div>

            <div className="card-footer">
                <button onClick={() => onLike(post.id)} className={`like-btn ${post.is_liked ? 'active' : ''}`}>
                    {post.is_liked ? '❤️' : '🤍'} {post.like_count}
                </button>
            </div>
        </div>
    );
};

export default PostCard;