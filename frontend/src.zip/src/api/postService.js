import axios from 'axios';

const API_URL = 'http://localhost:8000/api/posts/';

const getAuthHeader = () => {
    const token = localStorage.getItem('token');
    return { Authorization: `Bearer ${token}` };
};

const postService = {
    getClubFeed: () => axios.get(`${API_URL}my-feed/`, { headers: getAuthHeader() }),
    createPost: (formData) => {
    return axios.post(`${API_URL}create/`, formData, {
        headers: {
            ...getAuthHeader(),
            'Content-Type': 'multipart/form-data' // Dosya gönderimi için şart
        }
    });
    },
    handleGiveawayAction: (id, action) => axios.post(`${API_URL}giveaway/${id}/${action}/`, {}, { headers: getAuthHeader() }),
    // Yeni Eklenen Etkileşimler:
    toggleLike: (postId) => axios.post(`${API_URL}${postId}/like/`, {}, { headers: getAuthHeader() }),
    votePoll: (pollId, option) => axios.post(`${API_URL}${pollId}/vote/`, { option }, { headers: getAuthHeader() }),
    addComment: (postId, text) => axios.post(`${API_URL}${postId}/comment/`, { text }, { headers: getAuthHeader() })
};

export default postService;