from rest_framework import serializers
from posts.models import Post, Announcement, Event, Poll, Giveaway, Comment, PollResponse
from accounts.api.serializers.user_profile_serializer import UserProfileSerializer

class CommentSerializer(serializers.ModelSerializer):
    user = UserProfileSerializer(read_only=True)
    class Meta:
        model = Comment
        fields = ['id', 'user', 'text', 'date', 'like_count']

class PostBaseSerializer(serializers.ModelSerializer):
    """Tüm post tiplerinin ortak alanlarını döner"""
    club_name = serializers.CharField(source='club.name', read_only=True)
    is_liked = serializers.SerializerMethodField()
    comment_count = serializers.IntegerField(source='comments.count', read_only=True)

    class Meta:
        model = Post
        fields = ['id', 'club_name', 'text', 'image', 'posted_date', 'post_type', 'is_liked', 'comment_count']

    def get_is_liked(self, obj):
        user = self.context.get('request').user
        if user.is_authenticated:
            return obj.liked_by.filter(id=user.id).exists()
        return False

class EventSerializer(serializers.ModelSerializer):
    participant_count = serializers.IntegerField(source='participants.count', read_only=True)
    class Meta:
        model = Event
        fields = ['expire_date', 'location', 'participant_count']

class GiveawaySerializer(serializers.ModelSerializer):
    participant_count = serializers.IntegerField(source='participants.count', read_only=True)
    class Meta:
        model = Giveaway
        fields = ['deadline', 'winner_count', 'is_finished', 'participant_count']

class PostDetailSerializer(serializers.ModelSerializer):
    """Frontend'e giden ana paket. Post tipine göre detayları içine ekler."""
    details = serializers.SerializerMethodField()
    comments = CommentSerializer(many=True, read_only=True)
    club_name = serializers.CharField(source='club.name', read_only=True)

    class Meta:
        model = Post
        fields = ['id', 'club_name', 'text', 'image', 'posted_date', 'post_type', 'details', 'comments']

    def get_details(self, obj):
        if obj.post_type == 'event':
            return EventSerializer(obj.event).data
        elif obj.post_type == 'giveaway':
            return GiveawaySerializer(obj.giveaway).data
        # Anket ve Duyuru için de benzerleri eklenebilir
        return None
    
class PostCreateSerializer(serializers.ModelSerializer):
    # allow_null=True ve required=False kritik öneme sahip
    expire_date = serializers.DateTimeField(required=False, allow_null=True)
    deadline = serializers.DateTimeField(required=False, allow_null=True)
    winner_count = serializers.IntegerField(required=False, default=1)
    location = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    options = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    image = serializers.ImageField(required=False, allow_null=True)

    class Meta:
        model = Post
        fields = ['text', 'image', 'post_type', 'expire_date', 'location', 'deadline', 'winner_count', 'options']

    def to_internal_value(self, data):
        # Frontend'den gelen boş stringleri ("") temizle ve None yap
        mutable_data = data.copy()
        for field in ['expire_date', 'deadline', 'location', 'options']:
            if mutable_data.get(field) == "" or mutable_data.get(field) == "null":
                mutable_data[field] = None
        return super().to_internal_value(mutable_data)

    def validate(self, data):
        p_type = data.get('post_type')
        # Sadece ilgili tipte zorunluluk kontrolü yap
        if p_type == 'event' and not data.get('expire_date'):
            raise serializers.ValidationError({"expire_date": "Bu alan zorunludur."})
        if p_type == 'giveaway' and not data.get('deadline'):
            raise serializers.ValidationError({"deadline": "Bu alan zorunludur."})
        return data